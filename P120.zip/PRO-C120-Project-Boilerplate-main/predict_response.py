# Text Data Preprocessing Lib
import nltk
nltk.download('punkt')
nltk.download('wordnet')

# words to be ignored/omitted while framing the dataset
ignore_words = ['?', '!', ',', '.', "'s", "'m"]

import json
import pickle
import numpy as np
import random
import nltk
from nltk.stem import WordNetLemmatizer

# Model Load Lib
import tensorflow

# initialize the stemmer
lemmatizer = WordNetLemmatizer()

# load the model
model = tensorflow.keras.models.load_model('./chatbot_model.h5')

# Load data files
intents = json.loads(open('./intents.json').read())
words = pickle.load(open('./words.pkl', 'rb'))
classes = pickle.load(open('./classes.pkl', 'rb'))


def preprocess_user_input(user_input):
    # Tokenize the user input into words
    tokenized_words = nltk.word_tokenize(user_input)
    
    # Stem each word and ignore words that are not in the ignore_words list
    stemmed_words = [lemmatizer.lemmatize(word.lower()) for word in tokenized_words if word not in ignore_words]
    
    # Create the bag of words (BOW) representation
    bag = [0] * len(words)
    
    for stemmed_word in stemmed_words:
        if stemmed_word in words:
            bag[words.index(stemmed_word)] = 1
    
    return np.array(bag)


def bot_class_prediction(user_input):
    # Preprocess the user input and convert it into the bag of words
    inp = preprocess_user_input(user_input)
    
    # Predict the class using the trained model
    prediction = model.predict(np.array([inp]))  # Add the batch dimension
    predicted_class_label = np.argmax(prediction[0])
    
    return predicted_class_label


def bot_response(user_input):
    # Get the predicted class label
    predicted_class_label = bot_class_prediction(user_input)
    
    # Extract the predicted class from the predicted_class_label
    predicted_class = classes[predicted_class_label]
    
    # Find the corresponding intent for the predicted class
    for intent in intents['intents']:
        if intent['tag'] == predicted_class:
            # Choose a random response from the list of responses
            bot_response = random.choice(intent['responses'])
            return bot_response
    return "I'm sorry, I didn't understand that."


# Chatbot greeting
print("Hi, I am Stella. How can I help you?")

while True:
    # Take input from the user
    user_input = input('Type your message here: ')
    
    # Get the bot's response
    response = bot_response(user_input)
    
    # Print the bot's response
    print("Bot Response: ", response)
